<?php

namespace App\Service;

class PaymentService
{
    public function prepareContent()
    {
        return [
            "profile_id" => 108266,
            "tran_type"=> "sale",
            "tran_class"=> "ecom",
            "cart_id"=> "1212",
            "tokenise"=> "2",
            "cart_currency"=> "EGP",
            "cart_amount"=> 12,
            "cart_description"=> "Description of the items/services",
            "paypage_lang"=> "en",
            "customer_details"=> [
                "name"=> "first last",
                "email"=> "email@domain.com",
                "phone"=> "0522222222",
                "street1"=> "address street",
                "city"=> "dubai",
                "state"=> "du",
                "country"=> "AE",
                "zip"=> "12345"
            ],
            "shipping_details"=> [
                "name"=> "name1 last1",
                "email"=> "email1@domain.com",
                "phone"=> "971555555555",
                "street1"=> "street2",
                "city"=> "dubai",
                "state"=> "dubai",
                "country"=> "AE",
                "zip"=> "54321"
            ],
            "callback"=> route('callback'),
            "return"=> route('callback')
        ];
    }

}
