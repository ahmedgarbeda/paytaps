<?php

namespace App\Http\Controllers;

use App\Service\PaymentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class PayWithCard extends Controller
{
    const   PROFILE_ID = 108266,
        SERVER_KEY = 'SRJN6ZWZ2G-JGKTZBJJWW-JLL66Z2ML6',
        BASE_URL = 'https://secure-egypt.paytabs.com/payment/request';
    private PaymentService $paymentService;


    public function __construct(PaymentService $paymentService)
    {
        $this->paymentService = $paymentService;
    }


    public function initRequest()
    {
        $response = Http::withToken(self::SERVER_KEY)
                    ->post(self::BASE_URL, $this->paymentService->prepareContent());


        return $response->body();
    }


    public function callback(Request $request)
    {

    }

}
